# Anh Dang Periodic Table of Elements
#Images for the elements were taken from "http://www.chemicalelements.com/"

from Tkinter import *
import Tkinter as tk
import sqlite3 as lite
from PIL import Image, ImageTk


conn= lite.connect('table.db')
with conn:
    cur=conn.cursor()
#taking data out of sqlite and appending it in an multiple arrays
cur.execute("SELECT * FROM element ORDER BY atomic ASC")
atomic=[]
symbol=[]
mass=[]
name=[]
for row in cur.fetchall():
    atomic.append(row[3])
    symbol.append(row[1])
    name.append(row[2])
    mass.append(row[4])
#Create my own font with size
LARGE_FONT= ("Times New Roman", 70)


class PoE(tk.Tk):

    def __init__(self, *args, **kwargs):
        
        tk.Tk.__init__(self, *args, **kwargs)
        
#Title for main Frame
        tk.Tk.wm_title(self, "Periodic Table of Elements")
        window = tk.Frame(self)

        window.pack(side="top", fill="both", expand = True)

        window.grid_rowconfigure(0, weight=1)
        window.grid_columnconfigure(0, weight=1)


        self.frames = {}
#Populating the tuple with all the possible pages
        for F in (StartPage, Hydrogen,Lithium,Sodium,Potassium,Rubidium, Cesium, Francium, Berylium, Magnesium, Calcium, Strontium, Barium,
                  Radium,Scandium,Yttrium,Titanium,Zirconium,Hafnium,Rutherfordium,Vanadium,Niobium,Tantalum,Dubnium,Chromium,
                  Molybdenum,Tungsten,Seaborgium,Manganese,Technetium,Rhenium,Bohrium,Iron,Ruthenium,Osmium,Hassium,Cobalt,Rhodium,Iridium,Meltnerium,Nickel,Palladium,Platinum,Darmstadtium,Copper,Silver,Gold,Roentgenium,Zinc,Cadmium,Mercury,Copernicium,
                  Boron,Aluminum,Gallium,Indium,Thallium,Ununtrium,Carbon,Silicon,Germanium,Tin,Lead,Flerovium,Nitrogen,Phophorus,Arsenic,Antimony,Bismuth,Ununpentium,Oxygen,Sulfur,Selenium,Tellurium,Polonium,Livermorium,Fluorine,Chlorine,Bromine,Iodine,Astatine,Ununseptium,Helium,Neon,Argon,Krypton,Xenon,Radon,Ununoctium):

            frame = F(window, self)

            self.frames[F] = frame

            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame(StartPage)
#used to call a different frame
    def show_frame(self, cont):

        frame = self.frames[cont]
        frame.tkraise()


#First Frame where all the buttons are located
class StartPage(tk.Frame):


    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)
        label = tk.Label(self, text="Periodic Table Of Elements", font=LARGE_FONT)
        label.grid(row=0, column=0,columnspan=18)
#column 1
        #storing image into a location x
        #adjusting the height width using lambda to create a quick throw away function so it is only here when we call it
        #making the image of the button the image in location x
        #placing the button in a grid

        img1= PhotoImage(file="Hydrogen.gif")
        img1Btn=Button(self, width=70, height=70, image=img1,command=lambda: controller.show_frame(Hydrogen))
        img1Btn.image= img1
        img1Btn.grid(row=1, column=1)

        img2= PhotoImage(file="Lithium.gif")
        img2Btn=Button(self, width=70, height=70, image=img2,command=lambda: controller.show_frame(Lithium))
        img2Btn.image= img2
        img2Btn.grid(row=2, column=1)

        img3= PhotoImage(file="Sodium.gif")
        img3Btn=Button(self, width=70, height=70, image=img3,command=lambda: controller.show_frame(Sodium))
        img3Btn.image= img3
        img3Btn.grid(row=3, column=1)
        
        img4= PhotoImage(file="Potassium.gif")
        img4Btn=Button(self, width=70, height=70, image=img4,command=lambda: controller.show_frame(Potassium))
        img4Btn.image= img4
        img4Btn.grid(row=4, column=1)

        img5= PhotoImage(file="Rubidium.gif")
        img5Btn=Button(self, width=70, height=70, image=img5,command=lambda: controller.show_frame(Rubidium))
        img5Btn.image= img5
        img5Btn.grid(row=5, column=1)

        img6= PhotoImage(file="Cesium.gif")
        img6Btn=Button(self, width=70, height=70, image=img6,command=lambda: controller.show_frame(Cesium))
        img6Btn.image= img6
        img6Btn.grid(row=6, column=1)

        img7= PhotoImage(file="Francium.gif")
        img7Btn=Button(self, width=70, height=70, image=img7,command=lambda: controller.show_frame(Francium))
        img7Btn.image= img7
        img7Btn.grid(row=7, column=1)
#column 2        
        img8= PhotoImage(file="Berylium.gif")
        img8Btn=Button(self, width=70, height=70, image=img8,command=lambda: controller.show_frame(Berylium))
        img8Btn.image= img8
        img8Btn.grid(row=2, column=2)
        
        img9= PhotoImage(file="Magnesium.gif")
        img9Btn=Button(self, width=70, height=70, image=img9,command=lambda: controller.show_frame(Magnesium))
        img9Btn.image= img9
        img9Btn.grid(row=3, column=2)

        img10= PhotoImage(file="Calcium.gif")
        img10Btn=Button(self, width=70, height=70, image=img10,command=lambda: controller.show_frame(Calcium))
        img10Btn.image= img10
        img10Btn.grid(row=4, column=2)

        img11= PhotoImage(file="Strontium.gif")
        img11Btn=Button(self, width=70, height=70, image=img11,command=lambda: controller.show_frame(Strontium))
        img11Btn.image= img11
        img11Btn.grid(row=5, column=2)

        img12= PhotoImage(file="Barium.gif")
        img12Btn=Button(self, width=70, height=70, image=img12,command=lambda: controller.show_frame(Barium))
        img12Btn.image= img12
        img12Btn.grid(row=6, column=2)

        img13= PhotoImage(file="Radium.gif")
        img13Btn=Button(self, width=70, height=70, image=img13,command=lambda: controller.show_frame(Radium))
        img13Btn.image= img13
        img13Btn.grid(row=7, column=2)
#column 3
        img14= PhotoImage(file="Scandium.gif")
        img14Btn=Button(self, width=70, height=70, image=img14,command=lambda: controller.show_frame(Scandium))
        img14Btn.image= img14
        img14Btn.grid(row=4, column=3)

        img15= PhotoImage(file="Yttrium.gif")
        img15Btn=Button(self, width=70, height=70, image=img15,command=lambda: controller.show_frame(Yttrium))
        img15Btn.image= img15
        img15Btn.grid(row=5, column=3)

        img88= PhotoImage(file="57-71.gif")
        img88Btn=Button(self, width=70, height=70, image=img88,command=lambda: controller.show_frame(57-71))
        img88Btn.image= img88
        img88Btn.grid(row=6, column=3)

        img89= PhotoImage(file="89-103.gif")
        img89Btn=Button(self, width=70, height=70, image=img89,command=lambda: controller.show_frame(89-103))
        img89Btn.image= img89
        img89Btn.grid(row=7, column=3)
#column 4
        img16= PhotoImage(file="Titanium.gif")
        img16Btn=Button(self, width=70, height=70, image=img16,command=lambda: controller.show_frame(Titanium))
        img16Btn.image= img16
        img16Btn.grid(row=4, column=4)
        
        img17= PhotoImage(file="Zirconium.gif")
        img17Btn=Button(self, width=70, height=70, image=img17,command=lambda: controller.show_frame(Zirconium))
        img17Btn.image= img17
        img17Btn.grid(row=5, column=4)

        img18= PhotoImage(file="Hafnium.gif")
        img18Btn=Button(self, width=70, height=70, image=img18,command=lambda: controller.show_frame(Hafnium))
        img18Btn.image= img18
        img18Btn.grid(row=6, column=4)

        img19= PhotoImage(file="Rutherfordium.gif")
        img19Btn=Button(self, width=70, height=70, image=img19,command=lambda: controller.show_frame(Rutherfordium))
        img19Btn.image= img19
        img19Btn.grid(row=7, column=4)
#column 5
        img20= PhotoImage(file="Vanadium.gif")
        img20Btn=Button(self, width=70, height=70, image=img20,command=lambda: controller.show_frame(Vanadium))
        img20Btn.image= img20
        img20Btn.grid(row=4, column=5)

        img21= PhotoImage(file="Niobium.gif")
        img21Btn=Button(self, width=70, height=70, image=img21,command=lambda: controller.show_frame(Niobium))
        img21Btn.image= img21
        img21Btn.grid(row=5, column=5)

        img22= PhotoImage(file="Tantalum.gif")
        img22Btn=Button(self, width=70, height=70, image=img22,command=lambda: controller.show_frame(Tantalum))
        img22Btn.image= img22
        img22Btn.grid(row=6, column=5)

        img23= PhotoImage(file="Dubnium.gif")
        img23Btn=Button(self, width=70, height=70, image=img23,command=lambda: controller.show_frame(Dubnium))
        img23Btn.image= img23
        img23Btn.grid(row=7, column=5)
#column 6
        img24= PhotoImage(file="Chromium.gif")
        img24Btn=Button(self, width=70, height=70, image=img24,command=lambda: controller.show_frame(Chromium))
        img24Btn.image= img24
        img24Btn.grid(row=4, column=6)

        img25= PhotoImage(file="Molybdenum.gif")
        img25Btn=Button(self, width=70, height=70, image=img25,command=lambda: controller.show_frame(Molybdenum))
        img25Btn.image= img25
        img25Btn.grid(row=5, column=6)

        img26= PhotoImage(file="Tungsten.gif")
        img26Btn=Button(self, width=70, height=70, image=img26,command=lambda: controller.show_frame(Tungsten))
        img26Btn.image= img26
        img26Btn.grid(row=6, column=6)

        img27= PhotoImage(file="Seaborgium.gif")
        img27Btn=Button(self, width=70, height=70, image=img27,command=lambda: controller.show_frame(Seaborgium))
        img27Btn.image= img27
        img27Btn.grid(row=7, column=6)
#column #7
        img28= PhotoImage(file="Manganese.gif")
        img28Btn=Button(self, width=70, height=70, image=img28,command=lambda: controller.show_frame(Manganese))
        img28Btn.image= img28
        img28Btn.grid(row=4, column=7)

        img29= PhotoImage(file="Technetium.gif")
        img29Btn=Button(self, width=70, height=70, image=img29,command=lambda: controller.show_frame(Technetium))
        img29Btn.image= img29
        img29Btn.grid(row=5, column=7)

        img30= PhotoImage(file="Rhenium.gif")
        img30Btn=Button(self, width=70, height=70, image=img30,command=lambda: controller.show_frame(Rhenium))
        img30Btn.image= img30
        img30Btn.grid(row=6, column=7)

        img31= PhotoImage(file="Bohrium.gif")
        img31Btn=Button(self, width=70, height=70, image=img31,command=lambda: controller.show_frame(Bohrium))
        img31Btn.image= img31
        img31Btn.grid(row=7, column=7)
#column 8
        img32= PhotoImage(file="Iron.gif")
        img32Btn=Button(self, width=70, height=70, image=img32,command=lambda: controller.show_frame(Iron))
        img32Btn.image= img32
        img32Btn.grid(row=4, column=8)

        img33= PhotoImage(file="Ruthenium.gif")
        img33Btn=Button(self, width=70, height=70, image=img33,command=lambda: controller.show_frame(Ruthenium))
        img33Btn.image= img33
        img33Btn.grid(row=5, column=8)

        img34= PhotoImage(file="Osmium.gif")
        img34Btn=Button(self, width=70, height=70, image=img34,command=lambda: controller.show_frame(Osmium))
        img34Btn.image= img34
        img34Btn.grid(row=6, column=8)

        img35= PhotoImage(file="Hassium.gif")
        img35Btn=Button(self, width=70, height=70, image=img35,command=lambda: controller.show_frame(Hassium))
        img35Btn.image= img35
        img35Btn.grid(row=7, column=8)

#column 9

        img36= PhotoImage(file="Cobalt.gif")
        img36Btn=Button(self, width=70, height=70, image=img36,command=lambda: controller.show_frame(Cobalt))
        img36Btn.image= img36
        img36Btn.grid(row=4, column=9)

        img37= PhotoImage(file="Rhodium.gif")
        img37Btn=Button(self, width=70, height=70, image=img37,command=lambda: controller.show_frame(Rhodium))
        img37Btn.image= img37
        img37Btn.grid(row=5, column=9)

        img38= PhotoImage(file="Iridium.gif")
        img38Btn=Button(self, width=70, height=70, image=img38,command=lambda: controller.show_frame(Iridium))
        img38Btn.image= img38
        img38Btn.grid(row=6, column=9)

        img39= PhotoImage(file="Meitnerium.gif")
        img39Btn=Button(self, width=70, height=70, image=img39,command=lambda: controller.show_frame(Meitnerium))
        img39Btn.image= img39
        img39Btn.grid(row=7, column=9)

#column 10
        img40= PhotoImage(file="Nickel.gif")
        img40Btn=Button(self, width=70, height=70, image=img40,command=lambda: controller.show_frame(Nickel))
        img40Btn.image= img40
        img40Btn.grid(row=4, column=10)

        img41= PhotoImage(file="Palladium.gif")
        img41Btn=Button(self, width=70, height=70, image=img41,command=lambda: controller.show_frame(Palladium))
        img41Btn.image= img41
        img41Btn.grid(row=5, column=10)

        img42= PhotoImage(file="Platinum.gif")
        img42Btn=Button(self, width=70, height=70, image=img42,command=lambda: controller.show_frame(Platinum))
        img42Btn.image= img42
        img42Btn.grid(row=6, column=10)

        img43= PhotoImage(file="Darmstadtium.gif")
        img43Btn=Button(self, width=70, height=70, image=img43,command=lambda: controller.show_frame(Darmstadtium))
        img43Btn.image= img43
        img43Btn.grid(row=7, column=10)

#column 11
        img44= PhotoImage(file="Copper.gif")
        img44Btn=Button(self, width=70, height=70, image=img44,command=lambda: controller.show_frame(Copper))
        img44Btn.image= img44
        img44Btn.grid(row=4, column=11)

        img45= PhotoImage(file="Silver.gif")
        img45Btn=Button(self, width=70, height=70, image=img45,command=lambda: controller.show_frame(Silver))
        img45Btn.image= img45
        img45Btn.grid(row=5, column=11)

        img46= PhotoImage(file="Gold.gif")
        img46Btn=Button(self, width=70, height=70, image=img46,command=lambda: controller.show_frame(Gold))
        img46Btn.image= img46
        img46Btn.grid(row=6, column=11)

        img47= PhotoImage(file="Roentgenium.gif")
        img47Btn=Button(self, width=70, height=70, image=img47,command=lambda: controller.show_frame(Roentgenium))
        img47Btn.image= img47
        img47Btn.grid(row=7, column=11)

#column 12
        img48= PhotoImage(file="Zinc.gif")
        img48Btn=Button(self, width=70, height=70, image=img48,command=lambda: controller.show_frame(Zinc))
        img48Btn.image= img48
        img48Btn.grid(row=4, column=12)

        img49= PhotoImage(file="Cadmium.gif")
        img49Btn=Button(self, width=70, height=70, image=img49,command=lambda: controller.show_frame(Cadmium))
        img49Btn.image= img49
        img49Btn.grid(row=5, column=12)

        img50= PhotoImage(file="Mercury.gif")
        img50Btn=Button(self, width=70, height=70, image=img50,command=lambda: controller.show_frame(Mercury))
        img50Btn.image= img50
        img50Btn.grid(row=6, column=12)

        img51= PhotoImage(file="Copernicium.gif")
        img51Btn=Button(self, width=70, height=70, image=img51,command=lambda: controller.show_frame(Copernicium))
        img51Btn.image= img51
        img51Btn.grid(row=7, column=12)


#Column 13
        img52= PhotoImage(file="Boron.gif")
        img52Btn=Button(self, width=70, height=70, image=img52,command=lambda: controller.show_frame(Boron))
        img52Btn.image= img52
        img52Btn.grid(row=2, column=13)

        img53= PhotoImage(file="Aluminum.gif")
        img53Btn=Button(self, width=70, height=70, image=img53,command=lambda: controller.show_frame(Aluminum))
        img53Btn.image= img53
        img53Btn.grid(row=3, column=13)

        img54= PhotoImage(file="Gallium.gif")
        img54Btn=Button(self, width=70, height=70, image=img54,command=lambda: controller.show_frame(Gallium))
        img54Btn.image= img54
        img54Btn.grid(row=4, column=13)

        img55= PhotoImage(file="Indium.gif")
        img55Btn=Button(self, width=70, height=70, image=img55,command=lambda: controller.show_frame(Indium))
        img55Btn.image= img55
        img55Btn.grid(row=5, column=13)

        img56= PhotoImage(file="Thallium.gif")
        img56Btn=Button(self, width=70, height=70, image=img56,command=lambda: controller.show_frame(Thallium))
        img56Btn.image= img56
        img56Btn.grid(row=6, column=13)

        img57= PhotoImage(file="Ununtrium.gif")
        img57Btn=Button(self, width=70, height=70, image=img57,command=lambda: controller.show_frame(Ununtrium))
        img57Btn.image= img57
        img57Btn.grid(row=7, column=13)

#Column 14
        img58= PhotoImage(file="Carbon.gif")
        img58Btn=Button(self, width=70, height=70, image=img58,command=lambda: controller.show_frame(Carbon))
        img58Btn.image= img58
        img58Btn.grid(row=2, column=14)

        img59= PhotoImage(file="Silicon.gif")
        img59Btn=Button(self, width=70, height=70, image=img59,command=lambda: controller.show_frame(Silicon))
        img59Btn.image= img59
        img59Btn.grid(row=3, column=14)

        img60= PhotoImage(file="Germanium.gif")
        img60Btn=Button(self, width=70, height=70, image=img60,command=lambda: controller.show_frame(Germanium))
        img60Btn.image= img60
        img60Btn.grid(row=4, column=14)

        img61= PhotoImage(file="Tin.gif")
        img61Btn=Button(self, width=70, height=70, image=img61,command=lambda: controller.show_frame(Tin))
        img61Btn.image= img61
        img61Btn.grid(row=5, column=14)

        img62= PhotoImage(file="Lead.gif")
        img62Btn=Button(self, width=70, height=70, image=img62,command=lambda: controller.show_frame(Lead))
        img62Btn.image= img62
        img62Btn.grid(row=6, column=14)

        img63= PhotoImage(file="Flerovium.gif")
        img63Btn=Button(self, width=70, height=70, image=img63,command=lambda: controller.show_frame(Flerovium))
        img63Btn.image= img63
        img63Btn.grid(row=7, column=14)

#Column 15
        img63= PhotoImage(file="Nitrogen.gif")
        img63Btn=Button(self, width=70, height=70, image=img63,command=lambda: controller.show_frame(Nitrogen))
        img63Btn.image= img63
        img63Btn.grid(row=2, column=15)

        img64= PhotoImage(file="Phosphorus.gif")
        img64Btn=Button(self, width=70, height=70, image=img64,command=lambda: controller.show_frame(Phosphorus))
        img64Btn.image= img64
        img64Btn.grid(row=3, column=15)

        img65= PhotoImage(file="Arsenic.gif")
        img65Btn=Button(self, width=70, height=70, image=img65,command=lambda: controller.show_frame(Arsenic))
        img65Btn.image= img65
        img65Btn.grid(row=4, column=15)

        img66= PhotoImage(file="Antimony.gif")
        img66Btn=Button(self, width=70, height=70, image=img66,command=lambda: controller.show_frame(Antimony))
        img66Btn.image= img66
        img66Btn.grid(row=5, column=15)

        img67= PhotoImage(file="Bismuth.gif")
        img67Btn=Button(self, width=70, height=70, image=img67,command=lambda: controller.show_frame(Bismuth))
        img67Btn.image= img67
        img67Btn.grid(row=6, column=15)

        img68= PhotoImage(file="Ununpentium.gif")
        img68Btn=Button(self, width=70, height=70, image=img68,command=lambda: controller.show_frame(Ununpentium))
        img68Btn.image= img68
        img68Btn.grid(row=7, column=15)
#Column 16
        img69= PhotoImage(file="Oxygen.gif")
        img69Btn=Button(self, width=70, height=70, image=img69,command=lambda: controller.show_frame(Oxygen))
        img69Btn.image= img69
        img69Btn.grid(row=2, column=16)

        img70= PhotoImage(file="Sulfur.gif")
        img70Btn=Button(self, width=70, height=70, image=img70,command=lambda: controller.show_frame(Sulfur))
        img70Btn.image= img70
        img70Btn.grid(row=3, column=16)

        img71= PhotoImage(file="Selenium.gif")
        img71Btn=Button(self, width=70, height=70, image=img71,command=lambda: controller.show_frame(Selenium))
        img71Btn.image= img71
        img71Btn.grid(row=4, column=16)

        img72= PhotoImage(file="Tellurium.gif")
        img72Btn=Button(self, width=70, height=70, image=img72,command=lambda: controller.show_frame(Tellurium))
        img72Btn.image= img72
        img72Btn.grid(row=5, column=16)

        img73= PhotoImage(file="Polonium.gif")
        img73Btn=Button(self, width=70, height=70, image=img73,command=lambda: controller.show_frame(Polonium))
        img73Btn.image= img73
        img73Btn.grid(row=6, column=16)

        img74= PhotoImage(file="Livermorium.gif")
        img74Btn=Button(self, width=70, height=70, image=img74,command=lambda: controller.show_frame(Livermorium))
        img74Btn.image= img74
        img74Btn.grid(row=7, column=16)
#Column 17
        img75= PhotoImage(file="Fluorine.gif")
        img75Btn=Button(self, width=70, height=70, image=img75,command=lambda: controller.show_frame(Fluorine))
        img75Btn.image= img75
        img75Btn.grid(row=2, column=17)

        img76= PhotoImage(file="Chlorine.gif")
        img76Btn=Button(self, width=70, height=70, image=img76,command=lambda: controller.show_frame(Chlorine))
        img76Btn.image= img76
        img76Btn.grid(row=3, column=17)

        img77= PhotoImage(file="Bromine.gif")
        img77Btn=Button(self, width=70, height=70, image=img77,command=lambda: controller.show_frame(Bromine))
        img77Btn.image= img77
        img77Btn.grid(row=4, column=17)

        img78= PhotoImage(file="Iodine.gif")
        img78Btn=Button(self, width=70, height=70, image=img78,command=lambda: controller.show_frame(Iodine))
        img78Btn.image= img78
        img78Btn.grid(row=5, column=17)

        img79= PhotoImage(file="Astatine.gif")
        img79Btn=Button(self, width=70, height=70, image=img79,command=lambda: controller.show_frame(Astatine))
        img79Btn.image= img79
        img79Btn.grid(row=6, column=17)

        img80= PhotoImage(file="Ununseptium.gif")
        img80Btn=Button(self, width=70, height=70, image=img80,command=lambda: controller.show_frame(Ununseptium))
        img80Btn.image= img80
        img80Btn.grid(row=7, column=17)

#Column 18
        img81= PhotoImage(file="Helium.gif")
        img81Btn=Button(self, width=70, height=70, image=img81,command=lambda: controller.show_frame(Helium))
        img81Btn.image= img81
        img81Btn.grid(row=1, column=18)

        img82= PhotoImage(file="Neon.gif")
        img82Btn=Button(self, width=70, height=70, image=img82,command=lambda: controller.show_frame(Neon))
        img82Btn.image= img82
        img82Btn.grid(row=2, column=18)

        img83= PhotoImage(file="Argon.gif")
        img83Btn=Button(self, width=70, height=70, image=img83,command=lambda: controller.show_frame(Argon))
        img83Btn.image= img83
        img83Btn.grid(row=3, column=18)

        img84= PhotoImage(file="Krypton.gif")
        img84Btn=Button(self, width=70, height=70, image=img84,command=lambda: controller.show_frame(Krypton))
        img84Btn.image= img84
        img84Btn.grid(row=4, column=18)

        img85= PhotoImage(file="Xenon.gif")
        img85Btn=Button(self, width=70, height=70, image=img85,command=lambda: controller.show_frame(Xenon))
        img85Btn.image= img85
        img85Btn.grid(row=5, column=18)

        img87= PhotoImage(file="Radon.gif")
        img87Btn=Button(self, width=70, height=70, image=img87,command=lambda: controller.show_frame(Radon))
        img87Btn.image= img87
        img87Btn.grid(row=6, column=18)
    
        img86= PhotoImage(file="Ununoctium.gif")
        img86Btn=Button(self, width=70, height=70, image=img86,command=lambda: controller.show_frame(Ununoctium))
        img86Btn.image= img86
        img86Btn.grid(row=7, column=18)


###Key to be continued...
##        img90= PhotoImage(file="Nonmetal.gif")
##        img90i=tk.Label(self, width=70, height=70, image=img90)
##        img90i.image= img90
##        img90i.grid(row=11, column=4)

####***ALL PAGES SHARE THE SAME CODE***###

#When clicked on Hydrogen on start page        
class Hydrogen(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
#taking data out from the array and displaying them
        label = tk.Label(self, text=name[0], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[0], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[0], font=LARGE_FONT)
        
        Hydrogen= PhotoImage(file="Hydrogen1.gif")
        Hydrogen1=tk.Label(self, width=200,height=200,image=Hydrogen)
        Hydrogen1.image=Hydrogen
        Hydrogen1.pack(pady=0,padx=0)

        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        #This is the Return button to return to the startpage

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()




class Lithium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[2], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[2], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[2], font=LARGE_FONT)
        
        Lithium= PhotoImage(file="Lithium1.gif")
        Lithium1=tk.Label(self, width=200,height=200,image=Lithium)
        Lithium1.image=Lithium
        Lithium1.pack(pady=0,padx=0)
        
        label.pack(pady=10,padx=10)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()


class Sodium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[10], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[10], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[10], font=LARGE_FONT)

        Sodium= PhotoImage(file="Sodium1.gif")
        Sodium1=tk.Label(self, width=250,height=250,image=Sodium)
        Sodium1.image=Sodium
        Sodium1.pack(pady=0,padx=0)
        
        
        label.pack(pady=10,padx=10)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()


class Potassium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[18], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[18], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[18], font=LARGE_FONT)
        
        Potassium= PhotoImage(file="Potassium1.gif")
        Potassium1=tk.Label(self, width=300,height=300,image=Potassium)
        Potassium1.image=Potassium
        Potassium1.pack(pady=0,padx=0)
        
        label.pack(pady=10,padx=10)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

        
class Rubidium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[36], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[36], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[36], font=LARGE_FONT)
        
        Rubidium= PhotoImage(file="Rubidium1.gif")
        Rubidium1=tk.Label(self, width=300,height=300,image=Rubidium)
        Rubidium1.image=Rubidium
        Rubidium1.pack(pady=0,padx=0)
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
class Cesium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[54], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[54], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[54], font=LARGE_FONT)
        
        Cesium= PhotoImage(file="Cesium1.gif")
        Cesium1=tk.Label(self, width=325,height=325,image=Cesium)
        Cesium1.image=Cesium
        Cesium1.pack(pady=0,padx=0)
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
class Francium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[86], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[86], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[86], font=LARGE_FONT)

        Francium= PhotoImage(file="Francium1.gif")
        Francium1=tk.Label(self, width=400,height=400, image=Francium)
        Francium1.image=Francium
        Francium1.pack(anchor=W)
        
        label.pack()
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Berylium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[3], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[3], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[3], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        

class Magnesium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[11], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[11], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[11], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Calcium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[19], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[19], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[19], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Strontium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[37], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[37], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[37], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Barium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[55], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[55], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[55], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Radium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[87], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[87], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[87], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()



class Scandium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[20], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[20], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[20], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Yttrium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[38], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[38], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[38], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Titanium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[21], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[21], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[21], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Zirconium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[39], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[39], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[39], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Hafnium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[71], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[71], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[71], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Rutherfordium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[103], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[103], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[103], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Vanadium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[22], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[22], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[22], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Niobium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[40], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[40], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[40], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Tantalum(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[72], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[72], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[72], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Dubnium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[104], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[104], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[104], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Chromium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[23], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[23], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[23], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Molybdenum(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[41], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[41], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[41], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Tungsten(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[73], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[73], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[73], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Seaborgium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[105], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[105], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[105], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Manganese(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[24], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[24], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[24], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Technetium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[42], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[42], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[42], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Rhenium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[74], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[74], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[74], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Bohrium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[106], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[106], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[106], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Iron(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[25], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[25], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[25], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Ruthenium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[43], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[43], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[43], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Osmium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[75], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[75], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[75], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
class Hassium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[107], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[107], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[107], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Cobalt(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[26], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[26], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[26], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Rhodium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[44], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[44], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[44], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

        

        

class Rhodium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[44], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[44], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[44], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Iridium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[76], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[76], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[76], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Meltnerium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[108], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[108], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[108], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Nickel(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[27], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[27], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[27], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Palladium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[45], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[45], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[45], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Platinum(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[77], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[77], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[77], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Darmstadtium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[109], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[109], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[109], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Copper(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[28], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[28], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[28], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Silver(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[46], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[46], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[46], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Gold(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[78], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[78], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[78], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Roentgenium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[110], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[110], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[110], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Zinc(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[29], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[29], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[29], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Cadmium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[47], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[47], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[47], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Mercury(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[79], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[79], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[79], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Copernicium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[111], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[111], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[111], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Boron(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[4], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[4], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[4], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Aluminum(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[12], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[12], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[12], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Gallium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[30], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[30], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[30], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Indium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[48], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[48], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[48], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Thallium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[36], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[36], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[36], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Ununtrium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[112], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[112], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[112], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Carbon(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[5], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[5], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[5], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Silicon(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[13], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[13], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[13], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()
        
        

class Germanium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[31], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[31], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[31], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

        
class Tin(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[49], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[49], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[49], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Lead(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[81], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[81], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[81], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Flerovium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[113], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[113], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[113], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Nitrogen(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[6], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[6], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[6], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Phophorus(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[14], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[14], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[14], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Arsenic(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[32], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[32], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[32], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Antimony(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[50], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[50], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[50], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

        
class Bismuth(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[82], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[82], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[82], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Ununpentium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[114], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[114], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[114], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Oxygen(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[7], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[7], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[7], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Sulfur(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[15], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[15], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[15], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Selenium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[33], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[33], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[33], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Tellurium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[51], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[51], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[51], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Polonium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[83], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[83], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[83], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Livermorium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[115], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[115], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[115], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Fluorine(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[8], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[8], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[8], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Chlorine(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[16], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[16], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[16], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Bromine(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[34], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[34], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[34], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Iodine(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[52], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[52], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[52], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Astatine(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[84], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[84], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[84], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Ununseptium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[116], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[116], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[116], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Helium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[1], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[1], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[1], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Neon(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[9], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[9], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[9], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Argon(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[17], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[17], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[17], font=LARGE_FONT)


        Argon= PhotoImage(file="Argon1.gif")
        Argon1=tk.Label(self, width=240,height=240,image=Argon)
        Argon1.image=Argon
        Argon1.pack(pady=0,padx=0)
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Krypton(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[35], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[35], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[35], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()


class Xenon(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[53], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[53], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[53], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()


class Radon(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text=name[85], font=LARGE_FONT)
        label2 = tk.Label(self, text="Atomic #:", font=LARGE_FONT)
        label3 = tk.Label(self,text=atomic[85], font=LARGE_FONT)
        label4 = tk.Label(self,text="Mass:", font=LARGE_FONT)
        label5 = tk.Label(self,text=mass[85], font=LARGE_FONT)
        
        
        label.pack(pady=0,padx=0)
        label2.pack(pady=0,padx=0)
        label3.pack(pady=0,padx=0)
        label4.pack(pady=0,padx=0)
        label5.pack(pady=0,padx=0)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

class Ununoctium(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        

        button1 = tk.Button(self, text="Return",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()

        
        

app = PoE()
app.mainloop()
